<?php if (!empty($children)) : ?>
  <div class="node-fields">
    <?php print $children; ?>
  </div>
<?php endif; ?>